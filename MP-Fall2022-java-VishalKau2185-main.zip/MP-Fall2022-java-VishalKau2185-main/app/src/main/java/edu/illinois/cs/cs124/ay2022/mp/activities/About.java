package edu.illinois.cs.cs124.ay2022.mp.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import edu.illinois.cs.cs124.ay2022.mp.R;

public class About extends AppCompatActivity {

  @SuppressWarnings("checkstyle:Indentation")
  @Override
  protected void onCreate(final Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_about);
  }
}
